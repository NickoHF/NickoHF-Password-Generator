import random

num1 = '123456789'
wrd = 'qwertyuiopasdfghjklzxcvbnm'
num3 = wrd.upper()

numwrd = num1+wrd+num3

lst = list(numwrd)

random.shuffle(lst)

passw = ''.join([random.choice(lst) for x in range(12)])

print(passw)
input()
with open("password2.txt", "w") as file:
    print(passw, file=file)