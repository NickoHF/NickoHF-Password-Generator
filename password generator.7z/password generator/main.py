import random

num1 = '123456789'
wrd = 'qwertyuiopasdfghjklzxcvbnm'
wrd2 = wrd.upper()

ss = '!@#$%^&*'
str5 = num1+wrd+wrd2+ss

lst = list(str5)

random.shuffle(lst)

passw = ''.join([random.choice(lst) for x in range(12)])

print(passw)
input()
with open("password.txt", "w") as file:
    print(passw, file=file)